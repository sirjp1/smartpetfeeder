import tkinter as tk
import time

#This is the sliding text module that has the class with the functions
#that enable the feature of sliding texts to function and function properly.

class SlidingTextGUI:
    def __init__(self, master):
        self.master = master
        
# Footer frame
        self.footer = tk.Frame(self.master, bg="lightgray", height=30)
        self.footer.pack(side=tk.BOTTOM, fill=tk.X)

# Sliding text label
        self.sliding_text = tk.Label(self.footer, bg="lightgray", fg="black")
        self.sliding_text.pack()

# List of Nigerian slangs
        self.slangs = [
            "Wahala been dey wen i been dey code this project o",
            "Oya come see the fine project way i don do",
            "Abeg give me better mark for this project ooo",
            "Wetin dey sup my people",
            "Chop food cos problem no dey finish",
            "Gobe omo see gobe oo ",
            "Japa is a syndrome for better life",
            "Shakara don end o so brace up for better tin don land",
            "Yanga dey sleep trouble go wake am up",
            "Confam business dey for this coding oo",
            "Suffer no dey tire you? you gats make am o",
            "My Chairman I hail you o anything for the boys?",
            "With wetin my eye don see for python e b like say i don love code",
            "Tell me say you no love wetin you dey see here?",
            "Person suppose get two weeks break after this project",
            "if you dey in favour for at all 1 week break say aiii",
            "The Aiii's have it Mr Robinson. Over to you",
            "BYE PYTHON TILL WE MEET AGAIN"
        ]
        self.current_slang = 0
        self.position = self.master.winfo_width()
        self.slide_text()

#defining the sliding texts
    def slide_text(self):
        slang = self.slangs[self.current_slang]
        self.sliding_text.config(text=slang)
        
# Function to move the text
        self.position -= 2
        self.sliding_text.place(x=self.position, y=5)

# Here i reset position and change slang when text is off-screen
        if self.position + self.sliding_text.winfo_width() < 0:
            self.position = self.master.winfo_width()
            self.current_slang = (self.current_slang + 1) % len(self.slangs)

# Here i schedule the next movement
        self.master.after(20, self.slide_text)

print(f"\ncopyright Ezisi-Abana JohnPaul\n")
print(f"\nrefer to the References_page.py for the lists of references\n")
print(f"End of the slidingtext module page code")
