import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import time

#This is the gui module that has the class with the functions that enable the 
#gui to work effectively with customisations.Has same functions as the 
#pet_feeder module. The additions are the clock and it is from this module that
#the tinker gui calls the other modules to display and function

#Alright, let's set up our fancy pet feeder interface!
# This class is like the control panel for our high-tech pet feeding machine.
# We're naming our furry friend Sarah - hope she likes her automated meals!
class SmartPetFeederGUI:
    def __init__(self, master, feeder):
        self.master = master
        self.feeder = feeder
    
        self.label = tk.Label(master, text="Ezisi's Pet Name: Sarah")
        self.label.pack()

# Alright, let's set up the cool control panel for Sarah's smart feeder!
# We're creating a time input area, some fancy buttons,and even a digital clock.
# It's like building a mini mission control for your pet's meals!
        self.time_frame = tk.Frame(master)
        self.time_frame.pack()

# Here's where you can set the feeding time - just like programming your TV      
        self.hours_label = tk.Label(self.time_frame, text="Hours:")
        self.hours_label.pack(side=tk.LEFT)
        self.hours_entry = tk.Entry(self.time_frame, width=3)
        self.hours_entry.pack(side=tk.LEFT)       
        self.minutes_label = tk.Label(self.time_frame, text="Minutes:")
        self.minutes_label.pack(side=tk.LEFT)
        self.minutes_entry = tk.Entry(self.time_frame, width=3)
        self.minutes_entry.pack(side=tk.LEFT)
# Now for the fun buttons! It's like having a remote control for Sarah's meals
        self.schedule_button = tk.Button(master, text=
                  "Set feeding time for Sarah", command=self.schedule_feeding)
        self.schedule_button.pack()
        self.feed_now_button = tk.Button(master, text=
                                "Give food to Sarah Now", command=self.feed_now)
        self.feed_now_button.pack()
        self.view_history_button = tk.Button(master, text=
                            "Sarah's Feeding Record", command=self.view_history)
        self.view_history_button.pack()

#And here's a snazzy digital clock, because why not? 
#It's like we're in a sci-fi pet movie!
        self.clock_label = ttk.Label(master, font=('calibri', 40, 'bold'))
        self.clock_label.pack(pady=20)
        self.update_clock()

#This method schedules a feeding time for Sarah based on user input.
#It retrieves hours and minutes from entry fields, attempts to convert them 
#to integers,and then calls the feeder's schedule_feeding method to set
#the feeding time.If successful, it shows a confirmation message; 
#if not, it alerts the user to enter valid numbers.
    def schedule_feeding(self):
        try:
            hours = int(self.hours_entry.get())
            minutes = int(self.minutes_entry.get())
            time = self.feeder.schedule_feeding(hours, minutes)
            messagebox.showinfo("Scheduled", 
                                f"Sarah's Feeding scheduled for {time}")
        except ValueError:
            messagebox.showerror("Error", 
                            "Please enter valid numbers for hours and minutes")
            
 #This method triggers an immediate feeding for Sarah. It calls the 
 #feed_now method on the feeder and displays the result in a message box.
    def feed_now(self):
        message = self.feeder.feed_now()
        messagebox.showinfo("Sarah's Feeding", message)

 #This method opens a new window to display Sarah's feeding history.
 #It creates a text area where each feeding time is listed, formatted to show 
 #the date and time when Sarah was fed.
    def view_history(self):
        history_window = tk.Toplevel(self.master)
        history_window.title("Sarah's Feeding Records")
        history_window.geometry("300x200")

        history_text = tk.Text(history_window)
        history_text.pack()

        for time in self.feeder.get_feeding_history():
            history_text.insert(tk.END, 
        f"Sarah was Fed at: {time.strftime(
        '%Y-%m-%d %H:%M:%S')}\n")
            
# This method updates a clock label in the GUI every second.
# It retrieves the current time, formats it, and updates the clock label,
# ensuring that the displayed time is always current.
    def update_clock(self):
        current_time = time.strftime('%H:%M:%S')
        self.clock_label.configure(text=current_time)
        self.master.after(1000, self.update_clock)

#This method checks if there are any scheduled feedings for Sarah.
# If there is a scheduled feeding,it sets up a check to run again in 60 seconds,
# ensuring that the schedule is continuously monitored.
    def check_schedule(self):
        if self.feeder.check_schedule():
            self.master.after(60000, self.check_schedule)

print(f"\ncopyright Ezisi-Abana JohnPaul\n")
print(f"\nrefer to the References_page.py for the lists of references\n")
print(f"End of the gui_module page code")