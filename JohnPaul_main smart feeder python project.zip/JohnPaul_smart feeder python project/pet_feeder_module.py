import datetime
import csv
import random
import threading
import time

#This is the smartpet feeder module that has the class wwith the functions
#that enable the application to work effectively. functions such as the:
#portion size, the schedule for feeding,the history and saving the history in 
#csv file

class SmartPetFeeder:
    def __init__(self):
# Alright, let's set up our pet feeder! We'll start with a default portion size
# and empty lists for our feeding schedule and history. No timer yet!
        self.portion_size = 1.0
        self.schedule = []
        self.feeding_history = []
        self.timer = None
#Scheduling the timing for feeding
    def schedule_feeding(self, hours, minutes):
        scheduled_time = datetime.datetime.now() + datetime.timedelta(hours=
                                                        hours, minutes=minutes)
        self.schedule.append(scheduled_time)
# Cancel any existing timer as i had errors previously
        if self.timer:
            self.timer.cancel()
        
# Setting a new timer
        delay = (scheduled_time - datetime.datetime.now()).total_seconds()
        self.timer = threading.Timer(delay, self.feed_now)
        self.timer.start()       
        return scheduled_time.strftime('%H:%M')
    
# Alright, let's break this down:
#This function is like Sarah's personal waiter. When called, it serves her food,
#notes down the time (like a food diary),and gives us a little message about it.
    def feed_now(self):
        now = datetime.datetime.now()
        self.feeding_history.append(now)
        self.save_feeding_history()
        return f"Sarah's Food is dispensed at {now.strftime('%H:%M:%S')}!"
    
#This is like peeking into Sarah's food diary.It shows us when she's been fed.
    def get_feeding_history(self):
        return self.feeding_history
    
#Here's where we actually write in Sarah's food diary.We're being all tech-savvy
#and using a CSV file - fancy, right?
    def save_feeding_history(self):
        with open('feeding_history.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([self.feeding_history[-1].strftime
                             ('%Y-%m-%d %H:%M:%S')])
            
#This function is like checking Sarah's food bowl.It's a bit random (literally),
#but gives us an idea of how much food is left.
    def get_food_level(self):
        return random.randint(0, 100)
    
#This is Sarah's feeding schedule checker. It looks at the time, sees if it's
#feeding time, and if so, calls the waiter (feed_now) and crosses that 
#time off the list.It's like a to-do list, but for meals!
    def check_schedule(self):
        now = datetime.datetime.now()
        for scheduled_time in self.schedule:
            if now >= scheduled_time:
                self.feed_now()
                self.schedule.remove(scheduled_time)
        return len(self.schedule) > 0
    
print(f"\ncopyright Ezisi-Abana JohnPaul\n")
print(f"\nrefer to the References_page.py for the lists of references\n")
print(f"End of the pet_feeder_module page code")