import tkinter as tk
from pet_feeder_module import SmartPetFeeder
from gui_module import SmartPetFeederGUI
from slidingtext import SlidingTextGUI

#This is the main page from which the program would be run to start.
def main():
# Alright, let's set up our main window! This is where all the magic happens.
# We're creating a cool GUI for Ezisi's Smart Feeder - it's gonna be awesome!
    root = tk.Tk()
    root.title("Ezisi's Smart Feeder")  
# Giving our window a snazzy title
    root.geometry("600x400")  
# Making it a nice size - not too big, not too small

# Alright, let's set up our main stage! We're creating a frame that'll be the 
# star of the show, filling up all the space it can get.
    main_frame = tk.Frame(root)
    main_frame.pack(expand=True, fill=tk.BOTH)

# Now, let's roll out the red carpet! We're putting up a fancy welcome sign 
# to greet our users. Gotta make 'em feel special, you know?
    welcome_message = tk.Label(main_frame, text=
                           "Welcome to Ezisi's Smart Feeder!", 
                           font=("Arial", 14))
    welcome_message.pack(pady=10)

# Time to bring in the real MVP - our smart feeder! We're creating it and 
# then wrapping it up in a nice GUI. It's like dressing up our pet robot 
# in a snazzy interface suit!
    feeder = SmartPetFeeder()
    app = SmartPetFeederGUI(main_frame, feeder)
    
# Check schedule every minute
    def check_schedule_periodically():
        app.check_schedule()
        root.after(60000, check_schedule_periodically)
    
    check_schedule_periodically()

# Create the sliding text GUI
    sliding_text = SlidingTextGUI(root)

    root.mainloop()

if __name__ == "__main__":
    main()

print(f"\ncopyright Ezisi-Abana JohnPaul\n")
print(f"\nrefer to the References_page.py for the lists of references\n")
print(f"End of the smart_pet_feeder.py main page code")
