print(f"\nReferences:")
print(f"\nHere are some references for this code:")
print(f"\n1. Tkinter: \n- Official Python documentation: "
      f"https://docs.python.org/3/library/tkinter.html \n- Tkinter tutorial: "
      f"https://realpython.com/python-gui-tkinter/")
print(f"\n2.Creating a main window and configuring it: \n-Tkinter window basics"
      f":https://www.tutorialspoint.com/python/python_gui_programming.html")
print(f"\n3. Creating frames and packing widgets:"
      f"- Tkinter frames:"
      f"https://www.geeksforgeeks.org/python-tkinter-frame-widget/"
      f"- Pack geometry manager:"
      f" https://www.tutorialspoint.com/python/tk_pack.html")
print(f"\n4. Custom modules (SmartPetFeeder, SmartPetFeederGUI,SlidingTextGUI):"
      f" -Creating custom modules:"
      f" https://docs.python.org/3/tutorial/modules.html")
print(f"\n5. Main function and `if __name__ == __main__:`:"
      f"- Explanation and best practices:" 
      f"https://realpython.com/python-main-function")
print(f"\n6. Copyright notice: -Adding copyright notices to Python code:" 
      f"https://docs.python.org/3/tutorials/stdlib.html")
print(f"\n7. datetime module: \n- Documentation: "
      f"https://docs.python.org/3/library/datetime.html \n" 
      f"Used for handling dates and times:"
      f"(e.g., datetime.datetime.now(), datetime.timedelta) ")
print(f"\n8.csv module: \n-Documentation:"
      f"https://docs.python.org/3/library/csv.html "
      f"- Used for writing feeding history to a CSV file")
print(f"\n9. random module: \n  Documentation: "
      f"https://docs.python.org/3/library/random.html"
      f"- Used to generate random food levels")
print(f"\n10. Class methods:"    
      f" -Python Classes: https://docs.python.org/3/tutorial/classes.html")
print(f"\n11. File handling (with open(...)):"  
      f"- Python File I/O:" 
      f"https://docs.python.org/3/tutorial/inputoutput.html")
print(f"\n12. List operations (append, remove):"
      f"-Python Lists:" 
   f"https://docs.python.org/3/tutorial/datastructures.html#more-on-lists")
print(f"\n13. String formatting (strftime):"  
      f"- datetime.strftime():" 
      f"https://docs.python.org/3/library/datetime.html#datetime.date.strftime")
print(f"\n14. List comprehensions:"  
      f"- Python List Comprehensions:" 
      f"https://docs.python.org/3/tutorial/datastructures.html")
print(f"\n15. Tkinter ttk module:"  
      f"- Documentation:" 
      f"https://docs.python.org/3/library/tkinter.ttk.html")
print(f"\n16. Tkinter messagebox:"  
      f"- Documentation:" 
      f"https://docs.python.org/3/library/tkinter.messagebox.html")

print(f"\nCitations:\n"
      f"\n[1] https://realpython.com/python-gui-tkinter"
      f"\n[2] https://www.tutorialspoint.com/python/python_gui_programming.html"
      f"\n[3] https://python-textbok.readthedocs.io.html"
      f"\n[4] https://www.simplilearn.com"
      f"\n[5] https://www.youtube.com/watch?v=mop6g-c5HEY"
      f"\n[6] https://docs.python.org/zh-cn/3.13/library/tkinter.html"
      f"\n[7] https://python-forum.io/thread-40476.html"
      f"\n[8] https://stackoverflow.com"
      f"\n[9] https://chatgpt.com")